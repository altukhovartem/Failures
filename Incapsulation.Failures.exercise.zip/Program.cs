using System.Collections.Generic;
using System.Linq;
using NUnitLite;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}
